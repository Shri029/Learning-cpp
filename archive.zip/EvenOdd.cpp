#include<iostream>
using namespace std;

void main()
{ 
	int a;
	cout<<"Enter a number\t";
	cin>>a;
 
	if(a%2==0)
		cout<<"\n Number is even";
	else 
		cout<<"\n Number is odd\n";
}